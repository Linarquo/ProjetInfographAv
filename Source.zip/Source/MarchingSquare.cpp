#include "marchingSquare.h"

CMarchingSquare::CMarchingSquare(std::vector<SommetVoronoi> grilleVoronoi, int nbrLignes, int nbrColonnes) {
	nbrColonnes_ = nbrColonnes;
	nbrLignes_ = nbrLignes;
	m_grilleVoronoi = grilleVoronoi;

	creerLesTriangles(nbrLignes_, nbrColonnes_, m_grilleVoronoi);
}

CMarchingSquare::~CMarchingSquare(void) {

}

void CMarchingSquare::creerLesTriangles(int nbrLignes, int nbrColonnes, std::vector<SommetVoronoi> grilleVoronoi) {

}

void CMarchingSquare::dessiner() {

}