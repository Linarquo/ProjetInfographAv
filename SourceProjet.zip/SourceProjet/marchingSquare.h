#pragma once


#include "Cst.h"
#include "Modele3DAbstrait.h"
#include "Lumiere.h"
#include  <GL/glew.h> 
#include <vector>
#include "Var.h"



class CMarchingSquare:CModele3DAbstrait{
public :
	CMarchingSquare(std::vector<SommetVoronoi> grilleVoronoi, int nbrColonnes, int nbrLignes);

	~CMarchingSquare(void);

	void dessiner();

private :
	std::vector<SommetVoronoi> m_grilleVoronoi;
	std::vector<glm::vec3> m_positions;
	std::vector<glm::vec3> m_normals;
	std::vector<float> m_sommets;
	int nbrLignes_;
	int nbrColonnes_;
	
	unsigned int m_pBuffer;
	unsigned int m_nBuffer;

	void creerGrilles(std::vector<SommetVoronoi> grilleVoronoi);
	void creerTriangle(int cas, int x, int y);
};