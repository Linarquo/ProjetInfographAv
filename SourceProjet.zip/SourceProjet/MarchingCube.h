#pragma once


#include "Cst.h"
#include "Modele3DAbstrait.h"
#include "Lumiere.h"
#include  <GL/glew.h> 
#include <vector>
#include "Var.h"



class CMarchingCube :CModele3DAbstrait {
public:
	CMarchingCube(std::vector<SommetVoronoi3D> grilleVoronoi, int nbrColonnes, int nbrLignes, int nbrProfondeur);

	~CMarchingCube(void);

	void dessiner();

private:
	std::vector<SommetVoronoi3D> m_grilleVoronoi;
	std::vector<glm::vec3> m_positions;
	std::vector<glm::vec3> m_normals;
	std::vector<float> m_sommets;
	int nbrLignes_;
	int nbrColonnes_;
	int nbrProfondeur_;

	unsigned int m_pBuffer;
	unsigned int m_nBuffer;

	void creerGrilles(std::vector<SommetVoronoi3D> grilleVoronoi);
	void creerTriangle(Tetrahedron tetra);
};