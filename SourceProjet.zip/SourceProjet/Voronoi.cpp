#include "Voronoi.h"

CVoronoi::CVoronoi(DoubletFloat extent, float coarseLevelLenght, float tau, int nbColonnes, int nbLignes) {
	m_coarseLevelLength = coarseLevelLenght;
	m_extent = extent;
	m_tau = tau;
	m_nbColonnes = nbColonnes;
	m_nbLignes = nbLignes;

	std::vector<std::vector<DoubletFloat>> seeds_ordonnees = generate_seeds(m_coarseLevelLength, m_extent);
	m_resVoronoi = testVoronoi(seeds_ordonnees, m_nbLignes, m_nbColonnes, m_extent, m_coarseLevelLength, m_tau);

}

CVoronoi::~CVoronoi(void) {

}

ResultatVoronoi CVoronoi::getResVoronoi() {
	return m_resVoronoi;
}

DoubletFloat CVoronoi::additionDoublet(DoubletFloat d1, DoubletFloat d2) {
	DoubletFloat resultat;
	resultat.x = d1.x + d2.x;
	resultat.y = d1.y + d2.y;
	return resultat;
}

float CVoronoi::produitScalaire(DoubletFloat d1, DoubletFloat d2) {
	return d1.x * d2.x + d1.y * d2.y;
}

float CVoronoi::doubletDistance(DoubletFloat d1, DoubletFloat d2) {
	return sqrt((d2.x - d1.x)*(d2.x - d1.x) + (d2.y - d1.y)*(d2.y - d1.y));
}

DoubletFloat CVoronoi::scalaireDoublet(DoubletFloat d1, float scalaire) {
	DoubletFloat resultat;
	resultat.x = d1.x * scalaire;
	resultat.y = d1.y * scalaire;
	return resultat;
}


DoubletFloat CVoronoi::sample_new_point(DoubletFloat origin_square, float length_halfsquare, int subidx) {
	int dx = subidx % 2;
	int dy = subidx / 2;
	DoubletFloat dxdy;
	dxdy.x = (float)dx;
	dxdy.y = (float)dy;
	DoubletFloat offset = scalaireDoublet(dxdy, length_halfsquare);
	float random_offset_x = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
	float random_offset_y = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
	DoubletFloat random_offset;
	random_offset.x = random_offset_x;
	random_offset.y = random_offset_y;
	DoubletFloat resultat;
	resultat = scalaireDoublet(random_offset, length_halfsquare);
	resultat = additionDoublet(resultat, offset);
	resultat = additionDoublet(resultat, origin_square);

	return resultat;
}

float CVoronoi::density_func(DoubletFloat point, DoubletFloat extent) {
	//devra lire une image
	float seed_density_factor = 100.0f;
	return (point.x / extent.x)*seed_density_factor; //seeds / mm^2
}


std::vector<DoubletFloat> CVoronoi::subdivide_square(DoubletFloat origin_square, float length_square,
	std::vector<DoubletFloat> seeds,
	DoubletFloat extent) {
	float length_halfsquare = 0.5 * length_square;
	DoubletFloat doublet_length_halfsquare;
	doublet_length_halfsquare.x = length_halfsquare;
	doublet_length_halfsquare.y = length_halfsquare;
	float rho = density_func(additionDoublet(origin_square, doublet_length_halfsquare), extent);
	float target_seeds = pow(length_square, 2)*rho;
	if (target_seeds <= 4) {
		// 1st case: the cell is a leaf
		int shuffled_idx[] = { 1,2,3,4 };
		int permutationAleatoire = rand() % 24; //0 � 23
		int i;
		for (i = 0; i<permutationAleatoire; i++) {
			std::next_permutation(shuffled_idx, shuffled_idx + 4);
		}
		int min_samples = floor(target_seeds);
		float proba_last = target_seeds - min_samples;
		for (i = 0; i<min_samples; i++) {
			seeds.push_back(sample_new_point(origin_square, length_halfsquare, shuffled_idx[i]));
			//std::cout << "seed_size : " << seeds.size() << endl;
		}
		float tirage_random = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
		if (tirage_random <= proba_last && min_samples < 4) {
			seeds.push_back(sample_new_point(origin_square, length_halfsquare, shuffled_idx[min_samples]));
			//std::cout << "seed_size2 : " << seeds.size() << endl;
		}
	}
	else {
		// 2nd case: recursive call
		for (int i = 0; i<2; i++) {
			for (int j = 0; j<2; j++) {
				DoubletFloat offset;
				offset.x = i;
				offset.y = j;
				DoubletFloat origin_subsquare = additionDoublet(origin_square, scalaireDoublet(offset, length_halfsquare));
				seeds = subdivide_square(origin_subsquare, length_halfsquare, seeds, extent);
			}
		}
	}
	//std::cout << "seed_size3 : " << seeds.size() << endl;
	return seeds;
}

std::vector<std::vector<DoubletFloat>> CVoronoi::generate_seeds(float coarse_level_length, DoubletFloat extent) {
	
	std::cout << "Debut generation seeds" << std::endl;

	std::vector<std::vector<DoubletFloat>> resultat;
	std::vector<DoubletFloat> seeds;
	float origin_x = 0.0;
	float origin_y = 0.0;
	while (origin_x < extent.x) {
		DoubletFloat origin_square_coarse;
		origin_square_coarse.x = origin_x;
		origin_square_coarse.y = origin_y;
		seeds = subdivide_square(origin_square_coarse, coarse_level_length, seeds, extent);
		resultat.push_back(seeds);
		origin_y = origin_y + coarse_level_length;
		if (origin_y >= extent.y) {
			origin_y = 0.0;
			origin_x = origin_x + coarse_level_length;
		}
	}
	std::cout << "Fin generation seeds" << std::endl;
	return resultat;
}

std::vector<DoubletFloat> CVoronoi::getVoronoi(std::vector<std::vector<DoubletFloat>> seeds_ordonnees, float coord_x, float coord_y, DoubletFloat extent, float coarse_level_length) {
	int numero_ligne = max(0.0f, ceil(coord_x / coarse_level_length) - 1);
	int numero_colonne = max(0.0f, ceil(coord_y / coarse_level_length) - 1);
	int nombreLignesCells = ceil(extent.x / coarse_level_length);
	int nombreColonnesCells = ceil(extent.y / coarse_level_length);
	/*std::cout << "Nombre de ceils : " << seeds_ordonnees.size();
	std::cout << "Nombre de lignes cells: " << nombreLignesCells;
	std::cout << "Nombre de colonnes cells: " << nombreColonnesCells;
	std::cout << "Calcul : " << numero_ligne *nombreColonnesCells + numero_colonne;
	std::cout << "Coordonnees x :" << coord_x;*/
	std::vector<DoubletFloat> resultat;
	resultat = seeds_ordonnees[numero_ligne *nombreColonnesCells + numero_colonne];
	bool bas = false;
	bool haut = false;
	bool gauche = false;
	bool droite = false;
	if (numero_ligne == 0) {
		gauche = true;
	}
	if (numero_ligne == nombreLignesCells - 1) {
		droite = true;
	}
	if (numero_colonne == 0) {
		bas = true;
	}
	if (numero_colonne == nombreColonnesCells - 1) {
		haut = true;
	}
	std::vector<DoubletFloat> ceilAConcatener;
	if (!gauche) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[(numero_ligne - 1) *nombreColonnesCells + numero_colonne];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!droite) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[(numero_ligne + 1) *nombreColonnesCells + numero_colonne];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!haut) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[numero_ligne *nombreColonnesCells + (numero_colonne + 1)];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!bas) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[numero_ligne *nombreColonnesCells + (numero_colonne - 1)];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!haut && !gauche) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[(numero_ligne - 1) *nombreColonnesCells + (numero_colonne + 1)];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!haut && !droite) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[(numero_ligne + 1) *nombreColonnesCells + (numero_colonne + 1)];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!bas && !gauche) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[(numero_ligne - 1) *nombreColonnesCells + (numero_colonne - 1)];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	if (!bas && !droite) {
		std::vector<DoubletFloat> ceilAConcatener = seeds_ordonnees[(numero_ligne + 1) *nombreColonnesCells + (numero_colonne - 1)];
		resultat.insert(resultat.end(), ceilAConcatener.begin(), ceilAConcatener.end());
	}
	return resultat;
}

SommetVoronoi CVoronoi::determinerSommetVoronoi(std::vector<DoubletFloat> seedsInfluence, float coord_x, float coord_y, DoubletFloat extent, float tau) {
	DoubletFloat milieu;
	DoubletFloat point_q;
	point_q.x = coord_x;
	point_q.y = coord_y;
	SommetVoronoi resultat;
	resultat.x = coord_x;
	resultat.y = coord_y;
	bool accepte = false;
	int i = 0;
	//std::cout << seedsInfluence.size() << endl;
	//Determination de la seed la plus proche :
	int indicePlusProche = 0;
	DoubletFloat seedPlusProche = seedsInfluence[0];
	float distance_plus_proche = doubletDistance(point_q, seedPlusProche);
	for (int numero_seed = 1; numero_seed < seedsInfluence.size(); numero_seed++) {
		DoubletFloat seedCouranteTest = seedsInfluence[numero_seed];
		float distanceCourante = doubletDistance(point_q, seedCouranteTest);
		if (distanceCourante < distance_plus_proche) {
			seedPlusProche = seedCouranteTest;
			distance_plus_proche = distanceCourante;
			indicePlusProche = numero_seed;
		}
	}
	while (!accepte && i < seedsInfluence.size()) {
		if (i != indicePlusProche) {
			DoubletFloat seedCourante = seedsInfluence[i];
			milieu.x = (seedCourante.x + seedPlusProche.x) / 2;
			milieu.y = (seedCourante.y + seedPlusProche.y) / 2;
			float coeff_directeur;
			DoubletFloat pl;
			DoubletFloat vecteurDirecteur;
			if (seedCourante.x == seedPlusProche.x) {
				pl.x = seedPlusProche.x;
				pl.y = milieu.y;
			}
			else {
				if (seedCourante.y == seedPlusProche.y) {
					pl.x = milieu.x;
					pl.y = seedPlusProche.y;
				}
				else {
					float coeff_directeur_parallele = (seedPlusProche.y - seedCourante.y) / (seedPlusProche.x - seedCourante.x);
					float coeff_directeur_perpendiculaire = -1 / coeff_directeur_parallele;
					float b = milieu.y - coeff_directeur_perpendiculaire*milieu.x;
					float b_parallele = seedPlusProche.y - coeff_directeur_parallele*seedPlusProche.x;
					pl.x = (b_parallele - b) / (coeff_directeur_perpendiculaire - coeff_directeur_parallele);
					pl.y = coeff_directeur_perpendiculaire * pl.x + b;

					//vecteurDirecteur.x = 1;
					//vecteurDirecteur.y = coeff_directeur;
					//vecteurDirecteur = scalaireDoublet(vecteurDirecteur, 1 / (sqrt(1 + coeff_directeur*coeff_directeur)));
					//DoubletFloat vecMilieuQ;
					//vecMilieuQ.x = coord_x - milieu.x;
					//vecMilieuQ.y = coord_y - milieu.y;
				}
			}
			//std::cout << "distance : " << doubletDistance(pl, point_q) << endl;
			if (pl.x >= 0.0 && pl.x < extent.x && pl.y >= 0.0 && pl.y < extent.y) {
				if (doubletDistance(pl, point_q) <= tau) {
					accepte = true;
					for (int numero_seed = 0; numero_seed < seedsInfluence.size(); numero_seed++) {
						if (doubletDistance(pl, seedPlusProche) > doubletDistance(pl, seedsInfluence[numero_seed])) {
							accepte = false;
							break;
						}
					}
				}
			}
			else {
				//std::cout << "pl_x : " << pl.x << "pl_y : " << pl.y << endl;
			}
		}
		i++;
	}
	resultat.matiere = accepte;
	return resultat;
}

ResultatVoronoi CVoronoi::testVoronoi(std::vector<std::vector<DoubletFloat>> seeds_ordonnees, int nbLignes, int nbColonnes, DoubletFloat extent, float coarse_level_length, float tau) {
	std::cout << "Debut creationSommetVoronoi" << std::endl;
	ResultatVoronoi resultat;
	resultat.nbLignes = nbLignes;
	resultat.nbColonnes = nbColonnes;
	float pas_x = extent.x / nbLignes;
	float pas_y = extent.y / nbColonnes;
	for (int i = 0; i < nbLignes; i++) {
		std::cout << "Ligne : " << i << std::endl;
		for (int j = 0; j < nbColonnes; j++) {
			float coord_x = pas_x*i;
			float coord_y = pas_y*j;
			std::vector<DoubletFloat> seedsInfluence = getVoronoi(seeds_ordonnees, coord_x, coord_y, extent, coarse_level_length);
			SommetVoronoi sommetVoronoi = determinerSommetVoronoi(seedsInfluence, coord_x, coord_y, extent, tau);
			resultat.sommetsVoronoi.push_back(sommetVoronoi);
		}
	}
	std::cout << "Fin creationSommetVoronoi" << std::endl;
	return resultat;
}
