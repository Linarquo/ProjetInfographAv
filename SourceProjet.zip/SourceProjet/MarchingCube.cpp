#include "MarchingCube.h"
#include<iostream>

CMarchingCube::CMarchingCube(std::vector<SommetVoronoi3D> grilleVoronoi, int nbrColonnes, int nbrLignes, int nbrProfondeur) :
	CModele3DAbstrait(1.0f, (char*)NULL, TYPE_TEXTURE2D, false, false) {
	nbrColonnes_ = nbrColonnes;
	nbrLignes_ = nbrLignes;
	nbrProfondeur_ = nbrProfondeur;
	m_grilleVoronoi = grilleVoronoi;

	creerGrilles(m_grilleVoronoi);
}

CMarchingCube::~CMarchingCube(void) {
	glDeleteBuffers(1, &m_pBuffer);
	glDeleteBuffers(1, &m_nBuffer);
}

void CMarchingCube::creerGrilles(std::vector<SommetVoronoi3D> grilleVoronoi) {
	for (int x = 0; x < nbrColonnes_ - 1; x++) {
		for (int y = 0; y < nbrLignes_ - 1; y++) {
			for (int z = 0; z < nbrProfondeur_ - 1; z++) {
				Tetrahedron tetra;
				tetra.p1 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p2 = grilleVoronoi[(z+1) * nbrColonnes_ * nbrLignes_ + (y+1)*nbrColonnes_ + x+1];
				tetra.p3 = grilleVoronoi[(z+1) * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p4 = grilleVoronoi[(z+1) * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x+1];
				creerTriangle(tetra);

				tetra.p1 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p2 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x + 1];
				tetra.p3 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x+1];
				tetra.p4 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x + 1];
				creerTriangle(tetra);

				tetra.p1 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p2 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x + 1];
				tetra.p3 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x + 1];
				tetra.p4 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + (y+1)*nbrColonnes_ + x+1];
				creerTriangle(tetra);

				tetra.p1 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p2 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x + 1];
				tetra.p3 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + (y+1)*nbrColonnes_ + x];
				tetra.p4 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x+1];
				creerTriangle(tetra);

				tetra.p1 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p2 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x + 1];
				tetra.p3 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + (y+1)*nbrColonnes_ + x];
				tetra.p4 = grilleVoronoi[(z+1) * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x];
				creerTriangle(tetra);

				tetra.p1 = grilleVoronoi[z * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p2 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + (y + 1)*nbrColonnes_ + x + 1];
				tetra.p3 = grilleVoronoi[(z+1) * nbrColonnes_ * nbrLignes_ + y*nbrColonnes_ + x];
				tetra.p4 = grilleVoronoi[(z + 1) * nbrColonnes_ * nbrLignes_ + (y+1)*nbrColonnes_ + x];
				creerTriangle(tetra);

			}
		}
	}


	glGenBuffers(1, &m_pBuffer);
	glGenBuffers(1, &m_nBuffer);


	glBindBuffer(GL_ARRAY_BUFFER, m_pBuffer);
	glBufferData(GL_ARRAY_BUFFER, m_positions.size() * sizeof(glm::vec3), m_positions.data(), GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, m_nBuffer);
	glBufferData(GL_ARRAY_BUFFER, m_normals.size() * sizeof(glm::vec3), m_normals.data(), GL_STATIC_DRAW);
}

void CMarchingCube::dessiner() {

	//Activate location
	glEnableVertexAttribArray(1);
	//Bind buffer
	glBindBuffer(GL_ARRAY_BUFFER, m_pBuffer);
	//Specify internal format
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, m_nBuffer);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);



	glDrawArrays(GL_TRIANGLES, 0, m_positions.size());

}

void CMarchingCube::creerTriangle(Tetrahedron tetra) {
	glm::vec3 commonNormal = glm::vec3(0.0, 0.0, 1.0);

	int cas = 0;
	if (tetra.p1.matiere) cas += 1;
	if (tetra.p2.matiere) cas += 2;
	if (tetra.p3.matiere) cas += 4;
	if (tetra.p4.matiere) cas += 8;
	std::cout << cas << std::endl;
	switch (cas) {
	case 0:
	case 15:
		break;
	case 1:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(tetra.p1.x+(tetra.p2.x-tetra.p1.x)/(sqrt(3.0)*2.0),
			tetra.p1.y + (tetra.p2.y - tetra.p1.y) / (sqrt(3.0)*2.0),
			tetra.p1.z + (tetra.p2.z - tetra.p1.z) / (sqrt(3.0)*2.0)));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(tetra.p1.x + (tetra.p3.x - tetra.p1.x) / 2.0,
			tetra.p1.y + (tetra.p3.y - tetra.p1.y) / 2.0,
			tetra.p1.z + (tetra.p3.z - tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(tetra.p1.x + (tetra.p4.x - tetra.p1.x) / (sqrt(2.0)*2.0),
			tetra.p1.y + (tetra.p4.y - tetra.p1.y) / (sqrt(2.0)*2.0),
			tetra.p1.z + (tetra.p4.z - tetra.p1.z) / (sqrt(2.0)*2.0)));

		break;
	case 14:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p2.x) / 2.0,
			(tetra.p1.y + tetra.p2.y) / 2.0,
			(tetra.p1.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		break;
	case 2:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p1.x) / 2.0,
			(tetra.p2.y + tetra.p1.y) / 2.0,
			(tetra.p2.z + tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));
		break;

	case 13:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p1.x) / 2.0,
			(tetra.p2.y + tetra.p1.y) / 2.0,
			(tetra.p2.z + tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));
		break;

	case 3:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		break;

	case 12:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		break;

	case 4:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p1.x) / 2.0,
			(tetra.p3.y + tetra.p1.y) / 2.0,
			(tetra.p3.z + tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p2.x) / 2.0,
			(tetra.p3.y + tetra.p2.y) / 2.0,
			(tetra.p3.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p4.x) / 2.0,
			(tetra.p3.y + tetra.p4.y) / 2.0,
			(tetra.p3.z + tetra.p4.z) / 2.0));
		break;

	case 11:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p1.x) / 2.0,
			(tetra.p3.y + tetra.p1.y) / 2.0,
			(tetra.p3.z + tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p2.x) / 2.0,
			(tetra.p3.y + tetra.p2.y) / 2.0,
			(tetra.p3.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p4.x) / 2.0,
			(tetra.p3.y + tetra.p4.y) / 2.0,
			(tetra.p3.z + tetra.p4.z) / 2.0));
		break;

	case 5:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p2.x) / 2.0,
			(tetra.p1.y + tetra.p2.y) / 2.0,
			(tetra.p1.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p3.x) / 2.0,
			(tetra.p4.y + tetra.p3.y) / 2.0,
			(tetra.p4.z + tetra.p3.z) / 2.0));

		break;

	case 10:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p2.x) / 2.0,
			(tetra.p1.y + tetra.p2.y) / 2.0,
			(tetra.p1.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p4.x) / 2.0,
			(tetra.p1.y + tetra.p4.y) / 2.0,
			(tetra.p1.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p3.x) / 2.0,
			(tetra.p2.y + tetra.p3.y) / 2.0,
			(tetra.p2.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p3.x) / 2.0,
			(tetra.p4.y + tetra.p3.y) / 2.0,
			(tetra.p4.z + tetra.p3.z) / 2.0));

		break;

	case 6:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p2.x) / 2.0,
			(tetra.p1.y + tetra.p2.y) / 2.0,
			(tetra.p1.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p3.x) / 2.0,
			(tetra.p4.y + tetra.p3.y) / 2.0,
			(tetra.p4.z + tetra.p3.z) / 2.0));
		break;
	case 9:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p2.x) / 2.0,
			(tetra.p1.y + tetra.p2.y) / 2.0,
			(tetra.p1.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p2.x + tetra.p4.x) / 2.0,
			(tetra.p2.y + tetra.p4.y) / 2.0,
			(tetra.p2.z + tetra.p4.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p1.x + tetra.p3.x) / 2.0,
			(tetra.p1.y + tetra.p3.y) / 2.0,
			(tetra.p1.z + tetra.p3.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p3.x) / 2.0,
			(tetra.p4.y + tetra.p3.y) / 2.0,
			(tetra.p4.z + tetra.p3.z) / 2.0));
		break;
	case 7:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p1.x) / 2.0,
			(tetra.p4.y + tetra.p1.y) / 2.0,
			(tetra.p4.z + tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p2.x) / 2.0,
			(tetra.p4.y + tetra.p2.y) / 2.0,
			(tetra.p4.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p3.x) / 2.0,
			(tetra.p4.y + tetra.p3.y) / 2.0,
			(tetra.p4.z + tetra.p3.z) / 2.0));
		break;
	case 8:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p1.x) / 2.0,
			(tetra.p4.y + tetra.p1.y) / 2.0,
			(tetra.p4.z + tetra.p1.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p4.x + tetra.p2.x) / 2.0,
			(tetra.p4.y + tetra.p2.y) / 2.0,
			(tetra.p4.z + tetra.p2.z) / 2.0));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((tetra.p3.x + tetra.p3.x) / 2.0,
			(tetra.p4.y + tetra.p3.y) / 2.0,
			(tetra.p4.z + tetra.p3.z) / 2.0));
		break;
	}

}