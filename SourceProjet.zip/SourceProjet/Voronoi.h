#pragma once

#include "Cst.h"
#include <vector>
#include "Var.h"

#include <ctime>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <cmath>
#include <algorithm>
using namespace std;

class CVoronoi {
public :
	CVoronoi(DoubletFloat extent, float coarseLevelLenght, float tau, int nbColonnes, int nbLignes);
	~CVoronoi(void);

	ResultatVoronoi getResVoronoi();

private :

	ResultatVoronoi m_resVoronoi;
	DoubletFloat m_extent;
	float m_coarseLevelLength;
	float m_tau;
	int m_nbColonnes;
	int m_nbLignes;

	DoubletFloat additionDoublet(DoubletFloat d1, DoubletFloat d2);
	float produitScalaire(DoubletFloat d1, DoubletFloat d2);
	float doubletDistance(DoubletFloat d1, DoubletFloat d2);
	DoubletFloat scalaireDoublet(DoubletFloat d1, float scalaire);
	DoubletFloat sample_new_point(DoubletFloat origin_square, float length_halfsquare, int subidx);
	float density_func(DoubletFloat point, DoubletFloat extent);
	std::vector<DoubletFloat> subdivide_square(DoubletFloat origin_square, float length_square,
			std::vector<DoubletFloat> seeds,
			DoubletFloat extent);
	std::vector<std::vector<DoubletFloat>> generate_seeds(float coarse_level_length, DoubletFloat extent);
	std::vector<DoubletFloat> getVoronoi(std::vector<std::vector<DoubletFloat>> seeds_ordonnees, float coord_x, float coord_y, DoubletFloat extent, float coarse_level_length);
	SommetVoronoi determinerSommetVoronoi(std::vector<DoubletFloat> seedsInfluence, float coord_x, float coord_y, DoubletFloat extent, float tau);
	ResultatVoronoi testVoronoi(std::vector<std::vector<DoubletFloat>> seeds_ordonnees, int nbLignes, int nbColonnes, DoubletFloat extent, float coarse_level_length, float tau);

};