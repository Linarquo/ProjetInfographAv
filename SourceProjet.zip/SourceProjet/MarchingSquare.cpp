#include "marchingSquare.h"
#include<iostream>

CMarchingSquare::CMarchingSquare(std::vector<SommetVoronoi> grilleVoronoi, int nbrColonnes, int nbrLignes):
CModele3DAbstrait(1.0f,(char*)NULL, TYPE_TEXTURE2D, false, false)
{
	nbrColonnes_ = nbrColonnes;
	nbrLignes_ = nbrLignes;
	m_grilleVoronoi = grilleVoronoi;

	creerGrilles(m_grilleVoronoi);
}

CMarchingSquare::~CMarchingSquare(void) {
	glDeleteBuffers(1, &m_pBuffer);
	glDeleteBuffers(1, &m_nBuffer);
}


void CMarchingSquare::creerGrilles(std::vector<SommetVoronoi> grilleVoronoi) {
	int cas;
	for (int x = 0; x < nbrColonnes_-1; x++) {
		for (int y = 0; y < nbrLignes_-1; y++) {
			cas = 0;
			if (!grilleVoronoi[y*nbrColonnes_ + x].matiere) cas += 8;
			if (!grilleVoronoi[y*nbrColonnes_ + x + 1].matiere) cas += 4;
			if (!grilleVoronoi[(y + 1)*nbrColonnes_ + x].matiere) cas += 2;
			if (!grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].matiere) cas += 1;
			
			creerTriangle(cas, x, y);
		}
	}

	
	glGenBuffers(1, &m_pBuffer);
	glGenBuffers(1, &m_nBuffer);


	glBindBuffer(GL_ARRAY_BUFFER, m_pBuffer);
	glBufferData(GL_ARRAY_BUFFER, m_positions.size() * sizeof(glm::vec3), m_positions.data(), GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, m_nBuffer);
	glBufferData(GL_ARRAY_BUFFER, m_normals.size() * sizeof(glm::vec3), m_normals.data(), GL_STATIC_DRAW);
}

void CMarchingSquare::dessiner() {
	
	//Activate location
	glEnableVertexAttribArray(1);
	//Bind buffer
	glBindBuffer(GL_ARRAY_BUFFER, m_pBuffer);
	//Specify internal format
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, m_nBuffer);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

	glDrawArrays(GL_TRIANGLES, 0, m_positions.size());

}

void CMarchingSquare::creerTriangle(int cas, int x, int y) {
	glm::vec3 commonNormal = glm::vec3(0.0, 0.0, 1.0);
	switch (cas) {
	case 0:

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
										m_grilleVoronoi[y*nbrColonnes_ + x].y,
										0.0f));
		
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x+1].x,
										m_grilleVoronoi[y*nbrColonnes_ + x+1].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x].x,
										m_grilleVoronoi[(y+1)*nbrColonnes_ + x].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1 )*nbrColonnes_ + x].x,
										m_grilleVoronoi[(y + 1 )*nbrColonnes_ + x].y,
										0.0f));
		
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x+1].x,
										m_grilleVoronoi[y*nbrColonnes_ + x+1].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].x,
										m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].y,
										0.0f));
		

		
		break;
		

	case 1:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
										m_grilleVoronoi[y*nbrColonnes_ + x].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
			m_grilleVoronoi[y*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
			m_grilleVoronoi[y*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
										m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
										0.0f));

		

		break;

	case 2:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
										m_grilleVoronoi[y*nbrColonnes_ + x].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
										m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].x,
										m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
			0.0f));

		break;

	case 3:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
										m_grilleVoronoi[y*nbrColonnes_ + x].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
										m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x+ m_grilleVoronoi[y*nbrColonnes_ + x].x)/2.0,
										(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
										(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].x + m_grilleVoronoi[y*nbrColonnes_ + x+1].x) / 2.0,
										(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].y + m_grilleVoronoi[y*nbrColonnes_ + x+1].y) / 2.0,
										0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
										m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
										0.0f));

		break;

	case 4:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
			m_grilleVoronoi[y*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		break;

	case 5:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
			m_grilleVoronoi[y*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x+1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x+1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y+1)*nbrColonnes_ + x].y,
			0.0f));
	

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y+1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y+1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		break;

	case 6:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
			m_grilleVoronoi[y*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y,
			0.0f));

		break;


	case 7:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x].x,
			m_grilleVoronoi[y*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		break;

	case 8:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].y,
			0.0f));
		//
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));
		//
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y+1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		break;


	case 9:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x+1].x,
			m_grilleVoronoi[y*nbrColonnes_ + x+1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].x + m_grilleVoronoi[y*nbrColonnes_ + x+1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].y + m_grilleVoronoi[y*nbrColonnes_ + x+1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		break;


	case 10:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x+1].x,
			m_grilleVoronoi[y*nbrColonnes_ + x+1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].y,
			0.0f));


		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x+1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		break;

	case 11:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[y*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[y*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[y*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[y*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		break;
	case 12:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y+1)*nbrColonnes_ + x].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].y,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y+1)*nbrColonnes_ + x + 1].y,
			0.0f));
		break;

	case 13:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[y*nbrColonnes_ + x].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[y*nbrColonnes_ + x].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y,
			0.0f));

		break;

	case 14:
		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x + m_grilleVoronoi[y*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y + m_grilleVoronoi[y*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3((m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].x + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x) / 2.0,
			(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x].y + m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y) / 2.0,
			0.0f));

		m_normals.push_back(commonNormal);
		m_positions.push_back(glm::vec3(m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].x,
			m_grilleVoronoi[(y + 1)*nbrColonnes_ + x + 1].y,
			0.0f));

		break;


	case 15:
		break;
	}

}