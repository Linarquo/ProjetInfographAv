///////////////////////////////////////////////////////////////////////////////
///  @file main.cpp
///  @brief   le main du programme ProjetNuanceur pour le cours INF8702 de Polytechnique
///  @author  Fr�d�ric Plourde (2007)
///  @author  F�lix Gingras Harvey (2016)
///  @date    2007 / 2016
///  @version 2.0
///
///////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <gtc/matrix_inverse.hpp>
#include <gtx/transform.hpp>
#include <gtx/matrix_cross_product.hpp>
#include "textfile.h"
#include "GrilleQuads.h"
#include "Cst.h"
#include "Var.h"
#include "NuanceurProg.h"
#include "Materiau.h"
#include "Texture2D.h"
#include "Modele3DOBJ.h"
#include "marchingSquare.h"
#include "MarchingCube.h"
#include "Voronoi.h"


///////////////////////////////////////////////
// LES OBJETS                                //
///////////////////////////////////////////////

// les programmes de nuanceurs
CNuanceurProg progNuanceurCarte("Nuanceurs/carteSommets.glsl", "Nuanceurs/carteFragments.glsl", false);
CNuanceurProg progNuanceurMarchingSquare("Nuanceurs/marchingSquareSommets.glsl", "Nuanceurs/marchingSquareFragments.glsl", false);
// les diff�rents mat�riaux utilis�s dans le programme
CMateriau front_mat_ambiant_model(0.1, 0.1, 0.1, 1.0, 0.9, 0.8, 1.0, 1.0, 0.5, 0.5, 0.5, 1.0, 0.0, 0.0, 0.0, 1.0, 100.0);
CMateriau back_mat_ambiant_model(0.1, 0.1, 0.1, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 5.0);
CMateriau nurbs_mat_ambiant_model(0.8, 0.8, 0.8, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0);

// Les objets 3D graphiques (� instancier plus tard parce que les textures demandent le contexte graphique)

CGrilleQuads *cartePoly;
CMarchingSquare *marchingSquare;
CMarchingCube *marchingCube;
CVoronoi *Voronoi;


// Vecteurs cam�ra
glm::vec3 cam_position = glm::vec3(0, 0, -25);
glm::vec3 direction;
glm::vec3 cam_right;
glm::vec3 cam_up;

// Angle horizontale de la cam�ra: vers les Z
float horizontalAngle = 0.f;
// Angle vertical: vers l'horizon
float verticalAngle = 0.f;
// "Field of View" initial
float initialFoV = 45.0f;

float vitesseCamera = 15.0f; // 15 unit�s / seconde
float vitesseSouris = 0.05f;

double sourisX = 0;
double sourisY = 0;

///////////////////////////////////////////////
// PROTOTYPES DES FONCTIONS DU MAIN          //
///////////////////////////////////////////////
void initialisation (void);
void dessinerScene(void);
void dessinerCarte(void);
void dessinerMarchingSquare(void);
void attribuerValeursLumieres(GLuint progNuanceur);
void clavier(GLFWwindow *fenetre, int touche, int scancode, int action, int mods);
void mouvementSouris(GLFWwindow* window, double deltaT, glm::vec3& direction, glm::vec3& right, glm::vec3& up);
void redimensionnement(GLFWwindow *fenetre, int w, int h);
void rafraichirCamera(GLFWwindow* window, double deltaT);
void compilerNuanceurs();
void chargerBruitPerlin();

// le main
int main(int argc,char *argv[])
{
	// start GL context and O/S window using the GLFW helper library
	if (!glfwInit()) {
		fprintf(stderr, "ERREUR: impossible d'initialiser GLFW3\n");
		return 1;
	}

	GLFWwindow* fenetre = glfwCreateWindow(CVar::currentW , CVar::currentH, "INF8702 - Labo", NULL, NULL);
	if (!fenetre) {
		fprintf(stderr, "ERREUR: impossibe d'initialiser la fen�tre avec GLFW3\n");
		glfwTerminate();
		return 1;
	}
	glfwSetWindowPos(fenetre, 600, 100);

	// Rendre le contexte openGL courrant celui de la fen�tre
	glfwMakeContextCurrent(fenetre);

	// Combien d'updates d'�cran on attend apr�s l'appel � glfwSwapBuffers()
	// pour effectivement �changer les buffers et retourner
	glfwSwapInterval(1);

	// D�finir la fonction clavier
	glfwSetKeyCallback(fenetre, clavier);

	// Reset mouse position for next frame
	glfwSetCursorPos(fenetre, CVar::currentW / 2, CVar::currentH / 2);

	// D�finire le comportement du curseur
	glfwSetInputMode(fenetre, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

	// D�finir la fonction de redimensionnement
	glfwSetWindowSizeCallback(fenetre, redimensionnement);
	
	// v�rification de la version 4.X d'openGL
	glewInit();
	if (glewIsSupported("GL_VERSION_4_5"))
		printf("Pret pour OpenGL 4.5\n\n");
	else {
		printf("\nOpenGL 4.5 n'est pas supporte! \n");
		exit(1);
	}

	// Specifier le context openGL
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 5);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);


    // recueillir des informations sur le syst�me de rendu
	const GLubyte* renderer = glGetString(GL_RENDERER);
	const GLubyte* version = glGetString(GL_VERSION);
	printf("Materiel de rendu graphique: %s\n", renderer);
	printf("Plus r�cente vversion d'OpenGL supportee: %s\n\n", version);

    GLint max;
    glGetIntegerv(GL_MAX_TEXTURE_UNITS, &max);
    printf("GL_MAX_TEXTURE_UNITS = %d\n", max);

    glGetIntegerv(GL_MAX_VARYING_FLOATS, &max);
    printf("GL_MAX_VARYING_FLOATS = %d\n\n", max);


	if (!glfwExtensionSupported ("GL_EXT_framebuffer_object") ){
        printf("Objets 'Frame Buffer' NON supportes! :( ... Je quitte !\n");
        exit (1);
    } else {
        printf("Objets 'Frame Buffer' supportes :)\n\n");
    }


    // compiler et lier les nuanceurs
    compilerNuanceurs();

    // initialisation de variables d'�tat openGL et cr�ation des listes
    initialisation();
	
	double dernierTemps = glfwGetTime();
	int nbFrames = 0;
	
    // boucle principale de gestion des evenements
	while (!glfwWindowShouldClose(fenetre))
	{
		glfwPollEvents();

		//Temps ecoule en secondes depuis l'initialisation de GLFW
		double temps = glfwGetTime();
		double deltaT = temps - CVar::temps;
		CVar::temps = temps;

		nbFrames++;
		// Si �a fait une seconde que l'on a pas affich� les infos
		if (temps - dernierTemps >= 1.0){
			if (CVar::showDebugInfo){
				printf("%f ms/frame\n", 1000.0 / double(nbFrames));
				printf("Position: (%f,%f,%f)\n", cam_position.x, cam_position.y, cam_position.z);
			}
			nbFrames = 0;
			dernierTemps += 1.0;
		}
		
		// Rafraichir le point de vue selon les input clavier et souris
		rafraichirCamera(fenetre, deltaT);
		
		// Afficher nos mod�lests
		dessinerScene();

		// put the stuff we've been drawing onto the display
		glfwSwapBuffers(fenetre);

	}
	// close GL context and any other GLFW resources
	glfwTerminate();

    // on doit faire le m�nage... !
	delete CVar::lumieres[ENUM_LUM::LumPonctuelle];
	delete CVar::lumieres[ENUM_LUM::LumDirectionnelle];
	delete CVar::lumieres[ENUM_LUM::LumSpot];
	delete cartePoly;
	delete marchingSquare;

    // le programme n'arrivera jamais jusqu'ici
    return EXIT_SUCCESS;
}



// initialisation d'openGL
void initialisation (void) {
	////////////////////////////////////////////////////
	// CONSTRUCTION DES LUMI�RES
	////////////////////////////////////////////////////

	// LUMI�RE PONCTUELLE ORKENT�E (enum : LumPonctuelle - 0)
	CVar::lumieres[ENUM_LUM::LumPonctuelle] = new CLumiere(0.1f, 0.1f, 0.1f, 0.4f, 0.4f, 0.9f, 0.7f, 0.7f, 0.7f, 0.0f, -3.0f, -10.0f, 1.0f, true);
	CVar::lumieres[ENUM_LUM::LumPonctuelle]->modifierConstAtt(0.4);
	CVar::lumieres[ENUM_LUM::LumPonctuelle]->modifierLinAtt(0.0);
	CVar::lumieres[ENUM_LUM::LumPonctuelle]->modifierQuadAtt(0.0);

	// LUMI�RE SPOT (enum : LumSpot - 1)
	CVar::lumieres[ENUM_LUM::LumSpot] = new CLumiere(0.2f, 0.2f, 0.2f, 0.9f, 0.8f, 0.4f, 1.0f, 1.0f, 1.0f, 10.0f, 10.0f, -10.0f, 1.0f, true, -0.5f, -1.0f, 1.0f, 0.f, 30.0);

	// LUMI�RE DIRECTIONNELLE (enum : LumDirectionnelle - 2)
	CVar::lumieres[ENUM_LUM::LumDirectionnelle] = new CLumiere(0.1f, 0.1f, 0.1f, 0.8f, 0.8f, 0.8f, 0.4f, 0.4f, 0.4f, 5.0f, -5.0f, 5.0f, 0.0f, true);

	// les noms de fichier de la texture de la carte.
	std::vector<char*> texturesCarte;
	texturesCarte.push_back("textures/cartePolyRecto.bmp");
	texturesCarte.push_back("textures/cartePolyVerso.bmp");

	// charger la texture de perlin
	chargerBruitPerlin();

	cartePoly = new CGrilleQuads(&texturesCarte, 20.f, 12.f, 25, 25, 1.0f, false, true);
	// lier les attributs des nuanceurs
	//glBindAttribLocation(progNuanceurCarte.getProg(), CCst::indexTangente, "Tangent");
	
	///TEST MARCHINGSQUARE : VOIR DESSIN///
	/*
	std::vector<SommetVoronoi> grille;
	SommetVoronoi	p00, p10, p20, p30, p40, p50,
		p01, p11, p21, p31, p41, p51,
		p02, p12, p22, p32, p42, p52,
		p03, p13, p23, p33, p43, p53,
		p04, p14, p24, p34, p44, p54;

	p00.x = 0.0f; p00.y = 0.0f; p00.matiere = true; grille.push_back(p00);
	p10.x = 1.0f; p10.y = 0.0f; p10.matiere = false; grille.push_back(p10);
	p20.x = 2.0f; p20.y = 0.0f; p20.matiere = true; grille.push_back(p20);
	p30.x = 3.0f; p30.y = 0.0f; p30.matiere = false; grille.push_back(p30);
	p40.x = 4.0f; p40.y = 0.0f; p40.matiere = false; grille.push_back(p40);
	p50.x = 5.0f; p50.y = 0.0f; p50.matiere = false; grille.push_back(p50);
	p01.x = 0.0f; p01.y = 1.0f; p01.matiere = false; grille.push_back(p01);
	p11.x = 1.0f; p11.y = 1.0f; p11.matiere = false; grille.push_back(p11);
	p21.x = 2.0f; p21.y = 1.0f; p21.matiere = true; grille.push_back(p21);
	p31.x = 3.0f; p31.y = 1.0f; p31.matiere = true; grille.push_back(p31);
	p41.x = 4.0f; p41.y = 1.0f; p41.matiere = false; grille.push_back(p41);
	p51.x = 5.0f; p51.y = 1.0f; p51.matiere = false; grille.push_back(p51);
	p02.x = 0.0f; p02.y = 2.0f; p02.matiere = false; grille.push_back(p02);
	p12.x = 1.0f; p12.y = 2.0f; p12.matiere = true; grille.push_back(p12);
	p22.x = 2.0f; p22.y = 2.0f; p22.matiere = true; grille.push_back(p22);
	p32.x = 3.0f; p32.y = 2.0f; p32.matiere = true; grille.push_back(p32);
	p42.x = 4.0f; p42.y = 2.0f; p42.matiere = false; grille.push_back(p42);
	p52.x = 5.0f; p52.y = 2.0f; p52.matiere = false; grille.push_back(p52);
	p03.x = 0.0f; p03.y = 3.0f; p03.matiere = false; grille.push_back(p03);
	p13.x = 1.0f; p13.y = 3.0f; p13.matiere = false; grille.push_back(p13);
	p23.x = 2.0f; p23.y = 3.0f; p23.matiere = true; grille.push_back(p23);
	p33.x = 3.0f; p33.y = 3.0f; p33.matiere = false; grille.push_back(p33);
	p43.x = 4.0f; p43.y = 3.0f; p43.matiere = true; grille.push_back(p43);
	p53.x = 5.0f; p53.y = 3.0f; p53.matiere = true; grille.push_back(p53);
	p04.x = 0.0f; p04.y = 4.0f; p04.matiere = false; grille.push_back(p04);
	p14.x = 1.0f; p14.y = 4.0f; p14.matiere = false; grille.push_back(p14);
	p24.x = 2.0f; p24.y = 4.0f; p24.matiere = false; grille.push_back(p24);
	p34.x = 3.0f; p34.y = 4.0f; p34.matiere = true; grille.push_back(p34);
	p44.x = 4.0f; p44.y = 4.0f; p44.matiere = false; grille.push_back(p44);
	p54.x = 5.0f; p54.y = 4.0f; p54.matiere = false; grille.push_back(p54);


	marchingSquare = new CMarchingSquare(grille,6, 5);
	*/
	///FIN DE TEST MARCHINGSQUARE ///

	///TEST MARCHINGCUBE///
	std::vector<SommetVoronoi3D> grille;
	/*SommetVoronoi3D	p000, p100, p200, p300,
		p010, p110, p210, p310,
		p020, p120, p220, p320,
		p030, p130, p230, p330,
		p001, p101, p201, p301,
		p011, p111, p211, p311,
		p021, p121, p221, p321,
		p031, p131, p231, p331,
		p002, p102, p202, p302,
		p012, p112, p212, p312,
		p022, p122, p222, p322,
		p032, p132, p232, p332,
		p003, p103, p203, p303,
		p013, p113, p213, p313,
		p023, p123, p223, p323,
		p033, p133, p233, p333;

	p000.x = 0.0f; p000.y = 0.0f; p000.z = 0.0f; p000.matiere = false; grille.push_back(p000);
	p100.x = 1.0f; p100.y = 0.0f; p100.z = 0.0f; p100.matiere = false; grille.push_back(p100);
	p200.x = 2.0f; p200.y = 0.0f; p200.z = 0.0f; p200.matiere = false; grille.push_back(p200);
	p300.x = 3.0f; p300.y = 0.0f; p300.z = 0.0f; p300.matiere = false; grille.push_back(p300);
	p010.x = 0.0f; p010.y = 1.0f; p010.z = 0.0f; p010.matiere = false; grille.push_back(p010);
	p110.x = 1.0f; p110.y = 1.0f; p110.z = 0.0f; p110.matiere = false; grille.push_back(p110);
	p210.x = 2.0f; p210.y = 1.0f; p210.z = 0.0f; p210.matiere = false; grille.push_back(p210);
	p310.x = 3.0f; p310.y = 1.0f; p310.z = 0.0f; p310.matiere = false; grille.push_back(p310);
	p020.x = 0.0f; p020.y = 2.0f; p020.z = 0.0f; p020.matiere = false; grille.push_back(p020);
	p120.x = 1.0f; p120.y = 2.0f; p120.z = 0.0f; p120.matiere = false; grille.push_back(p120);
	p220.x = 2.0f; p220.y = 2.0f; p220.z = 0.0f; p220.matiere = false; grille.push_back(p220);
	p320.x = 3.0f; p320.y = 2.0f; p320.z = 0.0f; p320.matiere = false; grille.push_back(p320);
	p030.x = 0.0f; p030.y = 3.0f; p030.z = 0.0f; p030.matiere = false; grille.push_back(p030);
	p130.x = 1.0f; p130.y = 3.0f; p130.z = 0.0f; p130.matiere = false; grille.push_back(p130);
	p230.x = 2.0f; p230.y = 3.0f; p230.z = 0.0f; p230.matiere = false; grille.push_back(p230);
	p330.x = 3.0f; p330.y = 3.0f; p330.z = 0.0f; p330.matiere = false; grille.push_back(p330);

	p001.x = 0.0f; p001.y = 0.0f; p001.z = 1.0f; p001.matiere = false; grille.push_back(p001);
	p101.x = 1.0f; p101.y = 0.0f; p101.z = 1.0f; p101.matiere = false; grille.push_back(p101);
	p201.x = 2.0f; p201.y = 0.0f; p201.z = 1.0f; p201.matiere = false; grille.push_back(p201);
	p301.x = 3.0f; p301.y = 0.0f; p301.z = 1.0f; p301.matiere = false; grille.push_back(p301);
	p011.x = 0.0f; p011.y = 1.0f; p011.z = 1.0f; p011.matiere = false; grille.push_back(p011);
	p111.x = 1.0f; p111.y = 1.0f; p111.z = 1.0f; p111.matiere = true; grille.push_back(p111);
	p211.x = 2.0f; p211.y = 1.0f; p211.z = 1.0f; p211.matiere = true; grille.push_back(p211);
	p311.x = 3.0f; p311.y = 1.0f; p311.z = 1.0f; p311.matiere = false; grille.push_back(p311);
	p021.x = 0.0f; p021.y = 2.0f; p021.z = 1.0f; p021.matiere = false; grille.push_back(p021);
	p121.x = 1.0f; p121.y = 2.0f; p121.z = 1.0f; p121.matiere = true; grille.push_back(p121);
	p221.x = 2.0f; p221.y = 2.0f; p221.z = 1.0f; p221.matiere = true; grille.push_back(p221);
	p321.x = 3.0f; p321.y = 2.0f; p321.z = 1.0f; p321.matiere = false; grille.push_back(p321);
	p031.x = 0.0f; p031.y = 3.0f; p031.z = 1.0f; p031.matiere = false; grille.push_back(p031);
	p131.x = 1.0f; p131.y = 3.0f; p131.z = 1.0f; p131.matiere = false; grille.push_back(p131);
	p231.x = 2.0f; p231.y = 3.0f; p231.z = 1.0f; p231.matiere = false; grille.push_back(p231);
	p331.x = 3.0f; p331.y = 3.0f; p331.z = 1.0f; p331.matiere = false; grille.push_back(p331);

	p002.x = 0.0f; p002.y = 0.0f; p002.z = 2.0f; p002.matiere = false; grille.push_back(p002);
	p102.x = 1.0f; p102.y = 0.0f; p102.z = 2.0f; p102.matiere = false; grille.push_back(p102);
	p202.x = 2.0f; p202.y = 0.0f; p202.z = 2.0f; p202.matiere = false; grille.push_back(p202);
	p302.x = 3.0f; p302.y = 0.0f; p302.z = 2.0f; p302.matiere = false; grille.push_back(p302);
	p012.x = 0.0f; p012.y = 1.0f; p012.z = 2.0f; p012.matiere = true; grille.push_back(p012);
	p112.x = 1.0f; p112.y = 1.0f; p112.z = 2.0f; p112.matiere = true; grille.push_back(p112);
	p212.x = 2.0f; p212.y = 1.0f; p212.z = 2.0f; p212.matiere = false; grille.push_back(p212);
	p312.x = 3.0f; p312.y = 1.0f; p312.z = 2.0f; p312.matiere = false; grille.push_back(p312);
	p022.x = 0.0f; p022.y = 2.0f; p022.z = 2.0f; p022.matiere = true; grille.push_back(p022);
	p122.x = 1.0f; p122.y = 2.0f; p122.z = 2.0f; p122.matiere = true; grille.push_back(p122);
	p222.x = 2.0f; p222.y = 2.0f; p222.z = 2.0f; p222.matiere = false; grille.push_back(p222);
	p322.x = 3.0f; p322.y = 2.0f; p322.z = 2.0f; p322.matiere = false; grille.push_back(p322);
	p032.x = 0.0f; p032.y = 3.0f; p032.z = 2.0f; p032.matiere = false; grille.push_back(p032);
	p132.x = 1.0f; p132.y = 3.0f; p132.z = 2.0f; p132.matiere = false; grille.push_back(p132);
	p232.x = 2.0f; p232.y = 3.0f; p232.z = 2.0f; p232.matiere = false; grille.push_back(p232);
	p332.x = 3.0f; p332.y = 3.0f; p332.z = 2.0f; p332.matiere = false; grille.push_back(p332);

	p003.x = 0.0f; p003.y = 0.0f; p003.z = 3.0f; p003.matiere = false; grille.push_back(p003);
	p103.x = 1.0f; p103.y = 0.0f; p103.z = 3.0f; p103.matiere = false; grille.push_back(p103);
	p203.x = 2.0f; p203.y = 0.0f; p203.z = 3.0f; p203.matiere = false; grille.push_back(p203);
	p303.x = 3.0f; p303.y = 0.0f; p303.z = 3.0f; p303.matiere = false; grille.push_back(p303);
	p013.x = 0.0f; p013.y = 1.0f; p013.z = 3.0f; p013.matiere = false; grille.push_back(p013);
	p113.x = 1.0f; p113.y = 1.0f; p113.z = 3.0f; p113.matiere = false; grille.push_back(p113);
	p213.x = 2.0f; p213.y = 1.0f; p213.z = 3.0f; p213.matiere = false; grille.push_back(p213);
	p313.x = 3.0f; p313.y = 1.0f; p313.z = 3.0f; p313.matiere = false; grille.push_back(p313);
	p023.x = 0.0f; p023.y = 2.0f; p023.z = 3.0f; p023.matiere = false; grille.push_back(p023);
	p123.x = 1.0f; p123.y = 2.0f; p123.z = 3.0f; p123.matiere = false; grille.push_back(p123);
	p223.x = 2.0f; p223.y = 2.0f; p223.z = 3.0f; p223.matiere = false; grille.push_back(p223);
	p323.x = 3.0f; p323.y = 2.0f; p323.z = 3.0f; p323.matiere = false; grille.push_back(p323);
	p033.x = 0.0f; p033.y = 3.0f; p033.z = 3.0f; p033.matiere = false; grille.push_back(p033);
	p133.x = 1.0f; p133.y = 3.0f; p133.z = 3.0f; p133.matiere = false; grille.push_back(p133);
	p233.x = 2.0f; p233.y = 3.0f; p233.z = 3.0f; p233.matiere = false; grille.push_back(p233);
	p333.x = 3.0f; p333.y = 3.0f; p333.z = 3.0f; p333.matiere = false; grille.push_back(p333);*/

	SommetVoronoi3D p000, p100, p010, p110, p001, p101, p011, p111;

	p000.x = 0.0f; p000.y = 0.0f; p000.z = 0.0f; p000.matiere = true; grille.push_back(p000);
	p100.x = 1.0f; p100.y = 0.0f; p100.z = 0.0f; p100.matiere = false; grille.push_back(p100);
	p010.x = 0.0f; p010.y = 1.0f; p010.z = 0.0f; p010.matiere = false; grille.push_back(p010);
	p110.x = 1.0f; p110.y = 1.0f; p110.z = 0.0f; p110.matiere = false; grille.push_back(p110);
	p001.x = 0.0f; p001.y = 0.0f; p001.z = 1.0f; p001.matiere = false; grille.push_back(p001);
	p101.x = 1.0f; p101.y = 0.0f; p101.z = 1.0f; p101.matiere = false; grille.push_back(p101);
	p011.x = 0.0f; p011.y = 1.0f; p011.z = 1.0f; p011.matiere = false; grille.push_back(p011);
	p111.x = 1.0f; p111.y = 1.0f; p111.z = 1.0f; p111.matiere = false; grille.push_back(p111);
	marchingCube = new CMarchingCube(grille, 2, 2,2);

	///FIN DE TEST MARCHINGCUBE///

	int nbColonnes = 500;
	int nbLignes = 400;
	float coarseLevelLenght = 0.5;
	DoubletFloat extent;
	extent.x = 5.0;
	extent.y = 4.0;
	float tau = 0.05;

	/*std::cout << "Debut Voronoi" << std::endl;
	Voronoi = new CVoronoi(extent, coarseLevelLenght, tau, nbColonnes, nbLignes);
	std::cout << "Fin Voronoi" << std::endl;
	ResultatVoronoi res = Voronoi->getResVoronoi();
	std::cout << "Debut MarchingSquare" << std::endl;
	marchingSquare = new CMarchingSquare(res.sommetsVoronoi, res.nbColonnes, res.nbLignes);
	std::cout << "Fin MarchingSquare" << std::endl;*/

	// fixer la couleur de fond
	glClearColor(0.8, 0.8, 0.8, 1.0);

	// activer les etats openGL
	glEnable(GL_NORMALIZE);
	glEnable(GL_DEPTH_TEST);
	// fonction de profondeur
	glDepthFunc(GL_LEQUAL);
}

void dessinerCarte(void)
{
	GLenum err = 0;
	progNuanceurCarte.activer();
	// Cr�ation d'une matrice-mod�le.
	// D�fini la translation/rotaion/grandeur du mod�le.
	float scale = cartePoly->obtenirEchelle();
	glm::vec3 s(1, 1, 1);
	glm::mat4 scalingMatrix = glm::scale(s);

	glm::mat4 rotationMatrix;
	
	glm::vec3 rotationAxis = glm::vec3(0.0f, 0.0f, 1.0f);
	float a = glm::radians(180.f);
	rotationMatrix *= glm::rotate(a, rotationAxis);

	if (CVar::isRotating)
	{
		a = CVar::temps;
		rotationAxis = glm::vec3(0.f, 1.0f, 0.f);
		rotationMatrix *= glm::rotate(a, rotationAxis);
	}
	
	glm::vec3 t(0.f, 0.f, 0.f);
	glm::mat4 translationMatrix = glm::translate(t);

	glm::mat4 modelMatrix = translationMatrix * rotationMatrix * scalingMatrix;

	// Matrice Model-Vue-Projection:
	glm::mat4 mv = CVar::vue * modelMatrix;

	// Matrice Model-Vue-Projection:
	glm::mat4 mvp = CVar::projection * CVar::vue * modelMatrix;

	// Matrice pour normales (world matrix):
	glm::mat3 mv_n = glm::inverseTranspose(glm::mat3(CVar::vue * modelMatrix));
	err = glGetError();
	GLuint handle;

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "M");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &modelMatrix[0][0]);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "V");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &CVar::vue[0][0]);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "MVP");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &mvp[0][0]);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "MV");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &mv[0][0]);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "MV_N");
	glUniformMatrix3fv(handle, 1, GL_FALSE, &mv_n[0][0]);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "time");
	glUniform1f(handle, CVar::temps);
	
	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "animOn");
	glUniform1i(handle, (int)CVar::animModeleOn);
	err = glGetError();

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "perlinOn");
	glUniform1i(handle, (int)CVar::perlinOn);
	err = glGetError();

	////////////////    Fournir les valeurs de mat�riaux: //////////////////////////
	GLfloat component[4];
	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "frontMat.Ambient");
	front_mat_ambiant_model.obtenirKA(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "frontMat.Diffuse");
	front_mat_ambiant_model.obtenirKD(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "frontMat.Specular");
	front_mat_ambiant_model.obtenirKS(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "frontMat.Exponent");
	front_mat_ambiant_model.obtenirKE(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "frontMat.Shininess");
	glUniform1f(handle, front_mat_ambiant_model.obtenirShininess());

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "backMat.Ambient");
	back_mat_ambiant_model.obtenirKA(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "backMat.Diffuse");
	back_mat_ambiant_model.obtenirKD(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "backMat.Specular");
	back_mat_ambiant_model.obtenirKS(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "backMat.Exponent");
	back_mat_ambiant_model.obtenirKE(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "backMat.Shininess");
	glUniform1f(handle, back_mat_ambiant_model.obtenirShininess());

	/////////////////////////////////////////////////////////////////////////////////////

	attribuerValeursLumieres(progNuanceurCarte.getProg());
	err = glGetError();
	// ajouts d'autres uniforms
	if (CVar::lumieres[ENUM_LUM::LumPonctuelle]->estAllumee()) 
		progNuanceurCarte.uniform1("pointLightOn", 1);
	else
		progNuanceurCarte.uniform1("pointLightOn", 0);

	if (CVar::lumieres[ENUM_LUM::LumDirectionnelle]->estAllumee())
		progNuanceurCarte.uniform1("dirLightOn", 1);
	else
		progNuanceurCarte.uniform1("dirLightOn", 0);

	if (CVar::lumieres[ENUM_LUM::LumSpot]->estAllumee()) 
		progNuanceurCarte.uniform1("spotLightOn", 1);
	else
		progNuanceurCarte.uniform1("spotLightOn", 0);
	err = glGetError();

	//glVertexAttrib3f(CCst::indexTangente, 0.0, 0.0, 1.0);
	handle = glGetUniformLocation(progNuanceurCarte.getProg(), "Tangent");
	glUniform3f(handle, -1.0f, 1.0f, 0.0f);

	err = glGetError();
	cartePoly->dessiner();
	err = glGetError();
}

void dessinerMarchingSquare(void)
{
	GLenum err = 0;
	progNuanceurMarchingSquare.activer();
	// Cr�ation d'une matrice-mod�le.
	// D�fini la translation/rotaion/grandeur du mod�le.
	float scale = 1.0f;
	glm::vec3 s(1, 1, 1);
	glm::mat4 scalingMatrix = glm::scale(s);

	glm::mat4 rotationMatrix;

	glm::vec3 rotationAxis = glm::vec3(0.0f, 0.0f, 1.0f);
	float a = glm::radians(180.f);
	rotationMatrix *= glm::rotate(a, rotationAxis);

	glm::vec3 t(0.f, 0.f, 0.f);
	glm::mat4 translationMatrix = glm::translate(t);

	glm::mat4 modelMatrix = translationMatrix * rotationMatrix * scalingMatrix;

	// Matrice Model-Vue-Projection:
	glm::mat4 mv = CVar::vue * modelMatrix;

	// Matrice Model-Vue-Projection:
	glm::mat4 mvp = CVar::projection * CVar::vue * modelMatrix;

	// Matrice pour normales (world matrix):
	glm::mat3 mv_n = glm::inverseTranspose(glm::mat3(CVar::vue * modelMatrix));
	err = glGetError();
	GLuint handle;

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "M");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &modelMatrix[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "V");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &CVar::vue[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "MVP");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &mvp[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "MV");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &mv[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "MV_N");
	glUniformMatrix3fv(handle, 1, GL_FALSE, &mv_n[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "time");
	glUniform1f(handle, CVar::temps);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "animOn");
	glUniform1i(handle, (int)CVar::animModeleOn);
	err = glGetError();

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "perlinOn");
	glUniform1i(handle, (int)CVar::perlinOn);
	err = glGetError();

	////////////////    Fournir les valeurs de mat�riaux: //////////////////////////
	GLfloat component[4];
	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Ambient");
	front_mat_ambiant_model.obtenirKA(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Diffuse");
	front_mat_ambiant_model.obtenirKD(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Specular");
	front_mat_ambiant_model.obtenirKS(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Exponent");
	front_mat_ambiant_model.obtenirKE(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Shininess");
	glUniform1f(handle, front_mat_ambiant_model.obtenirShininess());

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Ambient");
	back_mat_ambiant_model.obtenirKA(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Diffuse");
	back_mat_ambiant_model.obtenirKD(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Specular");
	back_mat_ambiant_model.obtenirKS(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Exponent");
	back_mat_ambiant_model.obtenirKE(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Shininess");
	glUniform1f(handle, back_mat_ambiant_model.obtenirShininess());

	/////////////////////////////////////////////////////////////////////////////////////

	attribuerValeursLumieres(progNuanceurMarchingSquare.getProg());
	err = glGetError();
	// ajouts d'autres uniforms
	if (CVar::lumieres[ENUM_LUM::LumPonctuelle]->estAllumee())
		progNuanceurMarchingSquare.uniform1("pointLightOn", 1);
	else
		progNuanceurMarchingSquare.uniform1("pointLightOn", 0);

	if (CVar::lumieres[ENUM_LUM::LumDirectionnelle]->estAllumee())
		progNuanceurMarchingSquare.uniform1("dirLightOn", 1);
	else
		progNuanceurMarchingSquare.uniform1("dirLightOn", 0);

	if (CVar::lumieres[ENUM_LUM::LumSpot]->estAllumee())
		progNuanceurMarchingSquare.uniform1("spotLightOn", 1);
	else
		progNuanceurMarchingSquare.uniform1("spotLightOn", 0);
	err = glGetError();

	//glVertexAttrib3f(CCst::indexTangente, 0.0, 0.0, 1.0);
	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "Tangent");
	glUniform3f(handle, -1.0f, 1.0f, 0.0f);

	err = glGetError();
	marchingSquare->dessiner();
	err = glGetError();
}

void dessinerMarchingCube(void)
{
	GLenum err = 0;
	progNuanceurMarchingSquare.activer();
	// Cr�ation d'une matrice-mod�le.
	// D�fini la translation/rotaion/grandeur du mod�le.
	float scale = 1.0f;
	glm::vec3 s(1, 1, 1);
	glm::mat4 scalingMatrix = glm::scale(s);

	glm::mat4 rotationMatrix;

	glm::vec3 rotationAxis = glm::vec3(0.0f, 0.0f, 1.0f);
	float a = glm::radians(180.f);
	rotationMatrix *= glm::rotate(a, rotationAxis);

	glm::vec3 t(0.f, 0.f, 0.f);
	glm::mat4 translationMatrix = glm::translate(t);

	glm::mat4 modelMatrix = translationMatrix * rotationMatrix * scalingMatrix;

	// Matrice Model-Vue-Projection:
	glm::mat4 mv = CVar::vue * modelMatrix;

	// Matrice Model-Vue-Projection:
	glm::mat4 mvp = CVar::projection * CVar::vue * modelMatrix;

	// Matrice pour normales (world matrix):
	glm::mat3 mv_n = glm::inverseTranspose(glm::mat3(CVar::vue * modelMatrix));
	err = glGetError();
	GLuint handle;

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "M");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &modelMatrix[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "V");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &CVar::vue[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "MVP");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &mvp[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "MV");
	glUniformMatrix4fv(handle, 1, GL_FALSE, &mv[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "MV_N");
	glUniformMatrix3fv(handle, 1, GL_FALSE, &mv_n[0][0]);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "time");
	glUniform1f(handle, CVar::temps);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "animOn");
	glUniform1i(handle, (int)CVar::animModeleOn);
	err = glGetError();

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "perlinOn");
	glUniform1i(handle, (int)CVar::perlinOn);
	err = glGetError();

	////////////////    Fournir les valeurs de mat�riaux: //////////////////////////
	GLfloat component[4];
	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Ambient");
	front_mat_ambiant_model.obtenirKA(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Diffuse");
	front_mat_ambiant_model.obtenirKD(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Specular");
	front_mat_ambiant_model.obtenirKS(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Exponent");
	front_mat_ambiant_model.obtenirKE(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "frontMat.Shininess");
	glUniform1f(handle, front_mat_ambiant_model.obtenirShininess());

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Ambient");
	back_mat_ambiant_model.obtenirKA(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Diffuse");
	back_mat_ambiant_model.obtenirKD(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Specular");
	back_mat_ambiant_model.obtenirKS(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Exponent");
	back_mat_ambiant_model.obtenirKE(component);
	glUniform4fv(handle, 1, component);

	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "backMat.Shininess");
	glUniform1f(handle, back_mat_ambiant_model.obtenirShininess());

	/////////////////////////////////////////////////////////////////////////////////////

	attribuerValeursLumieres(progNuanceurMarchingSquare.getProg());
	err = glGetError();
	// ajouts d'autres uniforms
	if (CVar::lumieres[ENUM_LUM::LumPonctuelle]->estAllumee())
		progNuanceurMarchingSquare.uniform1("pointLightOn", 1);
	else
		progNuanceurMarchingSquare.uniform1("pointLightOn", 0);

	if (CVar::lumieres[ENUM_LUM::LumDirectionnelle]->estAllumee())
		progNuanceurMarchingSquare.uniform1("dirLightOn", 1);
	else
		progNuanceurMarchingSquare.uniform1("dirLightOn", 0);

	if (CVar::lumieres[ENUM_LUM::LumSpot]->estAllumee())
		progNuanceurMarchingSquare.uniform1("spotLightOn", 1);
	else
		progNuanceurMarchingSquare.uniform1("spotLightOn", 0);
	err = glGetError();

	//glVertexAttrib3f(CCst::indexTangente, 0.0, 0.0, 1.0);
	handle = glGetUniformLocation(progNuanceurMarchingSquare.getProg(), "Tangent");
	glUniform3f(handle, -1.0f, 1.0f, 0.0f);

	err = glGetError();
	marchingCube->dessiner();
	err = glGetError();
}


void dessinerScene()
{
	// � compl�ter
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	// D�commenter pour afficher!
	//dessinerCarte();

	//dessinerMarchingSquare();

	dessinerMarchingCube();

    // flush les derniers vertex du pipeline graphique
    glFlush();
}



///////////////////////////////////////////////////////////////////////////////
///  global public  clavier \n
///
///  fonction de rappel pour la gestion du clavier
///
///  @param [in]       pointeur GLFWwindow	R�f�rence � la fenetre GLFW
///  @param [in]       touche	int			ID de la touche
///  @param [in]       scancode int			Code sp�cifique � la plateforme et � l'ID
///  @param [in]       action	int			Action appliqu�e � la touche
///  @param [in]       mods		int			Modifier bits
///
///  @return Aucune
///
///  @author F�lix G. Harvey 
///  @date   2016-06-03
///
///////////////////////////////////////////////////////////////////////////////
void clavier(GLFWwindow* fenetre, int touche, int scancode, int action, int mods)
{

	switch (touche) {
	case GLFW_KEY_Q:{
		if (action == GLFW_PRESS)
			glfwSetWindowShouldClose(fenetre, GL_TRUE);
		break;
	}
	case  GLFW_KEY_ESCAPE:{
		if (action == GLFW_PRESS)
			glfwSetWindowShouldClose(fenetre, GL_TRUE);
		break;
	}
	case  GLFW_KEY_P:{
		if (action == GLFW_PRESS){
			if (CVar::isPerspective)
				CVar::isPerspective = false;
			else
				CVar::isPerspective = true;
		}
		break;
	}
	case  GLFW_KEY_R:{
		if (action == GLFW_PRESS){
			if (CVar::isRotating)
				CVar::isRotating = false;
			else
				CVar::isRotating = true;
		}
		break;
	}
	case  GLFW_KEY_I:{
		if (action == GLFW_PRESS){
			if (CVar::showDebugInfo)
				CVar::showDebugInfo = false;
			else
				CVar::showDebugInfo = true;
		}
		break;
	}
	case  GLFW_KEY_E:{
		if (action == GLFW_PRESS){
			if (CVar::animModeleOn)
				CVar::animModeleOn = false;
			else
				CVar::animModeleOn = true;
		}
		break;
	}
	case  GLFW_KEY_X: {
		if (action == GLFW_PRESS) {
			if (CVar::perlinOn)
				CVar::perlinOn = false;
			else
				CVar::perlinOn = true;
		}
		break;
	}
	case  GLFW_KEY_C:{
		if (action == GLFW_PRESS){
			if (CVar::mouseControl){
				CVar::mouseControl = false;
				glfwSetInputMode(fenetre, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
			}	
			else{
				CVar::mouseControl = true;
				glfwSetInputMode(fenetre, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
			}		
		}

		break;
	}
	case  GLFW_KEY_1:{
		if (action == GLFW_PRESS){
			if (CVar::lumieres[ENUM_LUM::LumDirectionnelle]->estAllumee())
				CVar::lumieres[ENUM_LUM::LumDirectionnelle]->eteindre();
			else
				CVar::lumieres[ENUM_LUM::LumDirectionnelle]->allumer();
		}

		break;
	}
	case  GLFW_KEY_2:{
		if (action == GLFW_PRESS){
			if (CVar::lumieres[ENUM_LUM::LumPonctuelle]->estAllumee())
				CVar::lumieres[ENUM_LUM::LumPonctuelle]->eteindre();
			else
				CVar::lumieres[ENUM_LUM::LumPonctuelle]->allumer();
		}
		break;
	}
	case  GLFW_KEY_3:{
		if (action == GLFW_PRESS){
			if (CVar::lumieres[ENUM_LUM::LumSpot]->estAllumee())
				CVar::lumieres[ENUM_LUM::LumSpot]->eteindre();
		else
			CVar::lumieres[ENUM_LUM::LumSpot]->allumer();
		}
		break;
	}

	// permuter le minFilter
	case GLFW_KEY_N:
	{
		if (action == GLFW_PRESS) {
			if (CVar::minFilter >= 5)
				CVar::minFilter = 0;
			else
				CVar::minFilter++;
		}
		break;
	}

	// permuter le magFilter
	case GLFW_KEY_M:
	{
		if (action == GLFW_PRESS) {
			if (CVar::magFilter >= 1)
				CVar::magFilter = 0;
			else
				CVar::magFilter++;
		}
		break;
	}

	}

}




///////////////////////////////////////////////////////////////////////////////
///  global public  redimensionnement \n
///
///  fonction de rappel pour le redimensionnement de la fen�tre graphique
///
///  @param [in]       w GLsizei    nouvelle largeur "w" en pixels
///  @param [in]       h GLsizei    nouvelle hauteur "h" en pixels
///
///  @return Aucune
///
///  @author Fr�d�ric Plourde 
///  @date   2007-12-14
///
///////////////////////////////////////////////////////////////////////////////
void redimensionnement(GLFWwindow* fenetre, int w, int h)
{
    CVar::currentW = w;
    CVar::currentH = h;
    glViewport(0, 0, w, h);
    dessinerScene();
}

void attribuerValeursLumieres(GLuint progNuanceur)
{
	GLenum error = glGetError();

	//Handle pour attribut de lumiere
	GLuint li_handle;

	li_handle = glGetUniformLocation(progNuanceur, "dirLightOn");
	error = glGetError();
	glUniform1i(li_handle, CVar::lumieres[ENUM_LUM::LumDirectionnelle]->estAllumee());
	error = glGetError();
	li_handle = glGetUniformLocation(progNuanceur, "pointLightOn");
	glUniform1i(li_handle, CVar::lumieres[ENUM_LUM::LumPonctuelle]->estAllumee());
	li_handle = glGetUniformLocation(progNuanceur, "spotLightOn");
	glUniform1i(li_handle, CVar::lumieres[ENUM_LUM::LumSpot]->estAllumee());
	error = glGetError();

	// Fournir les valeurs d'�clairage au nuanceur.
	// Les directions et positions doivent �tre en r�f�renciel de cam�ra. 
	for (int i = 0; i < CVar::lumieres.size(); i++)
	{
		//Placeholders pour contenir les valeurs
		GLfloat temp3[3];
		GLfloat temp4[4];
		glm::vec4 pos;
		glm::vec4 pos_cam;

		//Creer un descripteur bas� sur l'index de lumi�re
		std::string begin = "Lights[";
		int l_idx = i;
		std::string end = "]";
		std::string light_desc = begin + std::to_string(l_idx) + end;

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".Ambient").c_str());
		CVar::lumieres[i]->obtenirKA(temp3);
		glUniform3fv(li_handle, 1, &temp3[0]);
		error = glGetError();

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".Diffuse").c_str());
		CVar::lumieres[i]->obtenirKD(temp3);
		glUniform3fv(li_handle, 1, &temp3[0]);

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".Specular").c_str());
		CVar::lumieres[i]->obtenirKS(temp3);
		glUniform3fv(li_handle, 1, &temp3[0]);

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".Position").c_str());
		CVar::lumieres[i]->obtenirPos(temp4);

		// Transformer ici la direction/position de la lumi�re vers un r�f�renciel de cam�ra
		pos = glm::vec4(temp4[0], temp4[1], temp4[2], temp4[3]);
		pos = CVar::vue * pos;

		temp4[0] = pos.x;
		temp4[1] = pos.y;
		temp4[2] = pos.z;
		temp4[3] = pos.w;
		glUniform4fv(li_handle, 1, &temp4[0]);

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".SpotDir").c_str());
		CVar::lumieres[i]->obtenirSpotDir(temp3);
		//Transformer ici la direction du spot
		pos = glm::vec4(temp3[0], temp3[1], temp3[2], 0.0f);
		pos = CVar::vue * pos;
		temp3[0] = pos.x;
		temp3[1] = pos.y;
		temp3[2] = pos.z;
		glUniform3fv(li_handle, 1, &temp3[0]);

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".SpotExp").c_str());
		glUniform1f(li_handle, CVar::lumieres[i]->obtenirSpotExp());

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".SpotCutoff").c_str());
		glUniform1f(li_handle, CVar::lumieres[i]->obtenirSpotCutOff());

		li_handle = glGetUniformLocation(progNuanceur, (light_desc + ".Attenuation").c_str());
		glUniform3f(li_handle,
			CVar::lumieres[i]->obtenirConsAtt(),
			CVar::lumieres[i]->obtenirLinAtt(),
			CVar::lumieres[i]->obtenirQuadAtt());
	}

}


//////////////////////////////////////////////////////////
////////////  FONCTIONS POUR LA SOURIS ///////////////////
//////////////////////////////////////////////////////////

void mouvementSouris(GLFWwindow* window, double deltaT, glm::vec3& direction, glm::vec3& right, glm::vec3& up)
{
	if (CVar::mouseControl)
	{
		// D�placement de la souris:
		// Taille actuelle de la fenetre
		int mid_width, mid_height;
		glfwGetWindowSize(window, &mid_width, &mid_height);
		mid_width /= 2;
		mid_height /= 2;

		// Get mouse position
		double xpos, ypos;
		glfwGetCursorPos(window, &xpos, &ypos);

		// Reset mouse position for next frame
		glfwSetCursorPos(window, mid_width, mid_height);

		// Nouvelle orientation
		horizontalAngle += vitesseSouris * deltaT * float(mid_width - xpos);
		verticalAngle += vitesseSouris * deltaT * float(mid_height - ypos);
	}
	// Direction : Spherical coordinates to Cartesian coordinates conversion
	direction = glm::vec3(
		cos(verticalAngle) * sin(horizontalAngle),
		sin(verticalAngle),
		cos(verticalAngle) * cos(horizontalAngle)
		);

	// Right vector
	right = glm::vec3(
		sin(horizontalAngle - 3.14f / 2.0f),
		0,
		cos(horizontalAngle - 3.14f / 2.0f)
		);

	// Up vector : perpendicular to both direction and right
	up = glm::cross(right, direction);
}

//////////////////////////////////////////////////////////
////////////  FONCTIONS POUR LA CAM�RA ///////////////////
//////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
///  global public  rafraichirCamera \n
///
///  Fonction de gestion de la position de la cam�ra en coordonn�es sph�riques.
///  Elle s'occuper de trouver les coordonn�es x et y de la cam�ra � partir 
///  des theta et phi courants, puis fixe dans openGL la position de la cam�ra
///  � l'aide de gluLookAt().
///
///  @return Aucune
///
///  @author Fr�d�ric Plourde 
///  @date   2007-12-14
///
///////////////////////////////////////////////////////////////////////////////
void rafraichirCamera(GLFWwindow* fenetre, double deltaT)
{
	mouvementSouris(fenetre, deltaT, direction, cam_right, cam_up);

	// Move forward
	if (glfwGetKey(fenetre, GLFW_KEY_W) == GLFW_PRESS){
		cam_position += direction * (float)deltaT * vitesseCamera;
	}
	// Move backward
	if (glfwGetKey(fenetre, GLFW_KEY_S) == GLFW_PRESS){
		cam_position -= direction * (float)deltaT * vitesseCamera;
	}
	// Strafe right
	if (glfwGetKey(fenetre, GLFW_KEY_D) == GLFW_PRESS){
		cam_position += cam_right * (float)deltaT * vitesseCamera;
		}
	// Strafe left
	if (glfwGetKey(fenetre, GLFW_KEY_A) == GLFW_PRESS){
		cam_position -= cam_right * (float)deltaT * vitesseCamera;
	}

	//Matrice de projection:
	float ratio = (float)CVar::currentW / (float)CVar::currentH;
	if (CVar::isPerspective){
		// Cam�ra perspective: 
		// 
		
		CVar::projection = glm::perspective(glm::radians(45.0f), ratio, 0.001f, 3000.0f);
	}
	else
	{
		// Cam�ra orthographique :
		CVar::projection = glm::ortho(-5.0f*ratio, 5.0f*ratio,-5.0f, 5.0f, 0.001f, 3000.0f); // In world coordinates
	}

	// Matrice de vue:
	CVar::vue = glm::lookAt(
		cam_position,				// Position de la cam�ra
		cam_position + direction,   // regarde vers position + direction
		cam_up                  // Vecteur "haut"
		);
}


//////////////////////////////////////////////////////////
//////////  FONCTIONS POUR LES NUANCEURS /////////////////
//////////////////////////////////////////////////////////
void compilerNuanceurs () 
{
    // on compiler ici les programmes de nuanceurs qui furent pr�d�finis

	progNuanceurCarte.compilerEtLier();
	progNuanceurCarte.enregistrerUniformInteger("frontColorMap", CCst::texUnit_0);
	progNuanceurCarte.enregistrerUniformInteger("backColorMap", CCst::texUnit_1);
	progNuanceurCarte.enregistrerUniformInteger("normalMap", CCst::texUnit_2);

	/*progNuanceurSkybox.compilerEtLier();
	progNuanceurSkybox.enregistrerUniformInteger("colorMap", CCst::texUnit_0);

	progNuanceurGazon.compilerEtLier();
	progNuanceurGazon.enregistrerUniformInteger("colorMap", CCst::texUnit_0);*/

	progNuanceurMarchingSquare.compilerEtLier();
}

void chargerBruitPerlin()
{
	// construire la texture
	// calculer la texture de bruit de Perlin
	float* texNoise2D = make2DNoiseArray(CCst::noiseWidth, CCst::noiseHeight, 32, 1);

	// calculer la "normal map"
	vect3D* texNormal2D = compute2DNormalTexture(texNoise2D, CCst::noiseWidth, CCst::noiseHeight);

	// cr�er la texture
	glGenTextures(1, &CVar::perlinTex);
	glBindTexture(GL_TEXTURE_2D, CVar::perlinTex);

	// aiguiller openGL vers la zone m�moire contenant le graphisme de la texture
	glTexImage2D(GL_TEXTURE_2D, 0, 3, CCst::noiseWidth, CCst::noiseHeight, 0, GL_RGB, GL_FLOAT, texNormal2D);

	// lib�rer l'espace m�moire maintenant que la texture est copi�e dans la m�moire vid�o
	if (texNoise2D) {
		free(texNoise2D);
	}

	if (texNormal2D) {
		free(texNormal2D);
	}
}
